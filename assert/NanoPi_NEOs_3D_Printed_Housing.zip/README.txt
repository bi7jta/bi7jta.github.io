                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1698298
NanoPi NEO’s 3D Printed Housing by FriendlyARM3DPrinter is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

NanoPi NEO’s 3D Printed Housing
Low Profile, Luxury and Simplicity
3D Printing Files Available for free download
User Friendly
Edges have evenly spaced slots for better heat dissipation. Top cover with snap joints makes it easy toassemble.
Re-defines your NanoPi M3’s image, and
Creates a unique impression
It has appropriate room and openings for ports and interfaces.
The edges and bottom cover has evenly spaced slots for better heat dissipation.
Elegant, Calm and Practical
Notan eye candy But a real candy 

# Print Settings

Printer Brand: MakerBot
Printer: MakerBot Replicator 2X
Rafts: Doesn't Matter
Supports: Doesn't Matter

# Post-Printing

![Alt text](https://cdn.thingiverse.com/assets/d5/cd/39/74/7f/DSC_1226.jpg)

![Alt text](https://cdn.thingiverse.com/assets/d2/57/e8/44/d8/NEO-housing-1_05.jpg)

# How I Designed This

![Alt text](https://cdn.thingiverse.com/assets/15/c2/28/ab/07/DSC_1223.jpg)

## Screw Set

1.Screws: 2.5 x 30(mm)
2.Screws Nut 2.5(mm)


# Custom Section

## NanoPi NEO

Customized Jacket, Cute and Firm (3D Printing Files available),3D Printing Files Available for free download.
And you can find more information through this site:http://www.friendlyarm.com/index.php?route=product/product&product_id=132
NanoPi NEO’s 3D Printed Housing:
About US:http://www.friendlyarm.com/index.php?route=common/home